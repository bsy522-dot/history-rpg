// ============================================================
// 📜 data.js — 게임 데이터 (스토리, 맵, 유닛)
// ============================================================
// 이 파일만 수정하면 스토리·캐릭터·맵을 바꿀 수 있어요!
// ============================================================

// ── 에피소드 1 스토리 ─────────────────────────────
const STORY_LINES = [
  { speaker: "해설", text: "아득한 옛날, 하늘 위 천상계를 환인(桓因) 천제가 다스리고 있었다." },
  { speaker: "해설", text: "환인에게는 서자(庶子) 환웅이 있었는데, 자꾸 인간 세상을 내려다보며 탐을 냈다." },
  { speaker: "환웅", text: "\"아버지, 저 아래 인간들은 고통 속에 살고 있습니다. 제가 내려가 널리 이롭게 하고 싶습니다.\"" },
  { speaker: "환인", text: "\"네 뜻이 그러하다면... 태백산 신단수까지 내려가 보아라. 다만 쉽지 않을 것이다.\"" },
  { speaker: "환인", text: "\"내 천장(天將)들을 보내 네 의지를 시험하겠다. 이겨낸다면 천부인 세 개를 주마.\"" },
  { speaker: "해설", text: "환웅은 풍백(風伯)·우사(雨師)·운사(雲師) 세 신장을 이끌고 하강을 시작했다." },
  { speaker: "해설", text: "태백산 꼭대기의 신단수(神壇樹)를 향해 — 환인의 시련이 기다리고 있었다." },
  { speaker: "역사", text: "▶ 환웅의 하강은 고조선 건국 신화의 시작입니다. '홍익인간(弘益人間)' — 널리 인간을 이롭게 하라는 건국 이념은 지금도 대한민국 교육이념의 뿌리입니다." },
];

// ── 지형 타일 종류 ────────────────────────────────
// 각 숫자가 맵에서 어떤 땅인지 정의
const TILE = {
  PLAIN:  0,  // 평원 (이동 가능)
  FOREST: 1,  // 숲 (이동 불가, 장애물)
  MOUNT:  2,  // 산 (이동 불가)
  WATER:  3,  // 강/물 (이동 불가)
  SACRED: 4,  // 신단수 (목표지점)
  PATH:   5,  // 길 (이동 가능, 보너스)
  CLOUD:  6,  // 구름바다 (이동 불가)
  PEAK:   7,  // 높은 산봉우리 (이동 불가)
};

// 타일별 색상과 정보
const TILE_INFO = {
  [TILE.PLAIN]:  { name: '평원',   colors: ['#5a8a3a','#4d7a32'], passable: true },
  [TILE.FOREST]: { name: '숲',     colors: ['#2d5a1a','#1f4a12'], passable: false },
  [TILE.MOUNT]:  { name: '산',     colors: ['#7a7a6a','#6a6a5a'], passable: false },
  [TILE.WATER]:  { name: '강',     colors: ['#2a5a8a','#1a4a7a'], passable: false },
  [TILE.SACRED]: { name: '신단수', colors: ['#8a8a2a','#9a9a3a'], passable: true },
  [TILE.PATH]:   { name: '길',     colors: ['#8a7a5a','#7a6a4a'], passable: true },
  [TILE.CLOUD]:  { name: '구름',   colors: ['#aabbdd','#99aacc'], passable: false },
  [TILE.PEAK]:   { name: '높은산', colors: ['#9a9a8a','#8a8a7a'], passable: false },
};

// ── 맵 데이터 (20×20 태백산 일대) ─────────────────
// 위(천상) → 아래(태백산 신단수) 구조
// 환웅 부대는 위쪽(천상)에서 시작, 환인의 천장들은 중간~아래에 배치
const MAP_DATA = [
  [6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6],
  [6,6,6,6,6,5,5,5,5,5,5,5,5,5,6,6,6,6,6,6],
  [6,6,6,5,5,0,0,0,0,0,0,0,0,0,5,5,6,6,6,6],
  [6,6,5,0,0,0,0,1,0,0,0,1,0,0,0,0,5,6,6,6],
  [6,5,0,0,1,0,0,0,0,0,0,0,0,1,0,0,0,5,6,6],
  [6,0,0,0,0,0,0,0,5,5,0,0,0,0,0,0,0,0,6,6],
  [2,1,0,0,0,0,1,0,5,0,0,1,0,0,0,0,1,0,2,6],
  [7,2,0,0,0,0,0,0,5,0,0,0,0,0,0,0,0,0,2,7],
  [2,0,0,1,0,0,0,0,5,0,0,0,0,1,0,0,0,0,0,2],
  [0,0,0,0,0,3,3,0,5,0,3,3,0,0,0,0,0,0,0,1],
  [1,0,0,0,0,3,3,0,5,0,3,3,0,0,0,1,0,0,0,0],
  [0,0,0,1,0,0,0,0,5,0,0,0,0,0,0,0,0,1,0,0],
  [0,0,0,0,0,0,0,0,5,0,0,0,1,0,0,0,0,0,0,0],
  [1,0,0,0,0,1,0,5,5,5,0,1,0,0,0,0,0,0,0,1],
  [0,0,0,0,0,0,0,5,0,5,0,0,0,0,1,0,0,0,0,0],
  [0,0,1,0,0,0,5,0,0,0,5,0,0,0,0,0,1,0,0,0],
  [1,0,0,0,0,1,0,0,4,0,0,1,0,0,0,0,0,0,1,0],
  [0,0,0,0,0,0,1,1,1,1,1,0,0,0,1,0,0,0,0,0],
  [0,1,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,1,0,0],
  [0,0,0,1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0],
];

// ── 유닛 데이터 ───────────────────────────────────
// 아군 (환웅 진영)
const ALLY_UNITS = [
  {
    id: 'hwanwoong',
    name: '환웅',
    title: '환인의 아들, 천왕(天王)',
    hp: 65, maxHp: 65,
    atk: 18, def: 7, mov: 4, rng: 1,
    skills: [
      { name: '천부인·뇌격', type: 'attack', dmg: 28, rng: 2, desc: '천부인의 번개를 내린다' },
      { name: '홍익신광', type: 'heal', amount: 25, desc: '홍익의 빛으로 회복' },
    ],
    // 군대 색상 (갑옷, 깃발, 망토)
    colors: { armor: '#8B6914', cape: '#FFD700', flag: '#DAA520', skin: '#DEB887' },
    startX: 8, startY: 2,  // 맵에서 시작 위치
  },
  {
    id: 'pungbaek',
    name: '풍백',
    title: '바람의 신장, 선봉대장',
    hp: 45, maxHp: 45,
    atk: 15, def: 4, mov: 5, rng: 1,
    skills: [
      { name: '질풍참', type: 'attack', dmg: 22, rng: 1, desc: '바람의 칼날로 베어낸다' },
    ],
    colors: { armor: '#006400', cape: '#2E8B57', flag: '#3CB371', skin: '#DEB887' },
    startX: 7, startY: 3,
  },
  {
    id: 'wusa',
    name: '우사',
    title: '비의 신장, 군의관',
    hp: 38, maxHp: 38,
    atk: 10, def: 5, mov: 3, rng: 2,
    skills: [
      { name: '치유의 비', type: 'heal', amount: 22, desc: '비의 축복으로 회복' },
      { name: '폭우격', type: 'attack', dmg: 18, rng: 2, desc: '폭우를 쏟아붓는다' },
    ],
    colors: { armor: '#1a3a6a', cape: '#4169E1', flag: '#4682B4', skin: '#DEB887' },
    startX: 9, startY: 3,
  },
  {
    id: 'wunsa',
    name: '운사',
    title: '구름의 신장, 참모',
    hp: 40, maxHp: 40,
    atk: 13, def: 5, mov: 4, rng: 1,
    skills: [
      { name: '운무차폐', type: 'heal', amount: 18, desc: '안개로 아군을 숨겨 회복' },
      { name: '뇌운격', type: 'attack', dmg: 20, rng: 1, desc: '번개구름을 떨어뜨린다' },
    ],
    colors: { armor: '#4a2a6a', cape: '#8A2BE2', flag: '#9370DB', skin: '#DEB887' },
    startX: 8, startY: 4,
  },
];

// 적군 (환인의 천장들)
const ENEMY_UNITS = [
  {
    id: 'chunmu',
    name: '천무장',
    title: '환인의 제1천장, 총사령관',
    hp: 55, maxHp: 55,
    atk: 17, def: 6, mov: 3, rng: 1,
    skills: [],
    colors: { armor: '#8B0000', cape: '#FF0000', flag: '#CD3333', skin: '#DEB887' },
    startX: 8, startY: 12,
  },
  {
    id: 'noegong',
    name: '뇌공',
    title: '천둥의 장수',
    hp: 40, maxHp: 40,
    atk: 15, def: 4, mov: 4, rng: 2,
    skills: [],
    colors: { armor: '#8B4500', cape: '#FF8C00', flag: '#CD6600', skin: '#DEB887' },
    startX: 6, startY: 10,
  },
  {
    id: 'hwasin',
    name: '화신',
    title: '불의 장수',
    hp: 38, maxHp: 38,
    atk: 16, def: 3, mov: 4, rng: 1,
    skills: [],
    colors: { armor: '#8B1A1A', cape: '#FF4500', flag: '#EE3B3B', skin: '#DEB887' },
    startX: 10, startY: 10,
  },
  {
    id: 'sanryeong',
    name: '산령',
    title: '산의 수호자',
    hp: 48, maxHp: 48,
    atk: 13, def: 9, mov: 2, rng: 1,
    skills: [],
    colors: { armor: '#5a4a3a', cape: '#A0522D', flag: '#8B7355', skin: '#DEB887' },
    startX: 8, startY: 14,
  },
  {
    id: 'sujang',
    name: '수장',
    title: '물의 장수',
    hp: 36, maxHp: 36,
    atk: 14, def: 4, mov: 3, rng: 2,
    skills: [],
    colors: { armor: '#104E8B', cape: '#1E90FF', flag: '#1C86EE', skin: '#DEB887' },
    startX: 7, startY: 11,
  },
];

// ── 승리 보상 ─────────────────────────────────────
const VICTORY_DATA = {
  reward: '천부인(天符印) 세 개 — 거울·칼·방울 각성!',
  historyNote: '환인의 시련을 통과한 환웅은 천부인 세 개를 가지고 태백산 신단수 아래로 내려왔다. 풍백·우사·운사와 3,000의 무리를 이끌고 신시(神市)를 열어 인간 세상을 다스렸다. 이것이 고조선 건국의 서막이다. (BC 2333년)',
};
